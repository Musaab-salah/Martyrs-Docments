-- Database Backup for martyrs_archive
-- Created: 2025-09-03T19:00:44.344Z
-- Server: localhost:3306

-- Table structure for table `admins`
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','super_admin') COLLATE utf8mb4_unicode_ci DEFAULT 'admin',
  `is_active` tinyint(1) DEFAULT '1',
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `admins`
INSERT INTO `admins` (`id`, `username`, `email`, `password_hash`, `role`, `is_active`, `last_login`, `created_at`, `updated_at`) VALUES (1, 'admin', 'admin@martyrsarchive.com', '$2a$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj/RK.s5uO.G', 'super_admin', 1, NULL, '"2025-08-31T19:17:50.000Z"', '"2025-08-31T19:17:50.000Z"');

-- Table structure for table `martyrs`
DROP TABLE IF EXISTS `martyrs`;
CREATE TABLE `martyrs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `place_of_martyrdom` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_martyrdom` date NOT NULL,
  `age` int DEFAULT NULL,
  `biography` text COLLATE utf8mb4_unicode_ci,
  `education` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `occupation` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `personal_story` text COLLATE utf8mb4_unicode_ci,
  `attachments` json DEFAULT NULL,
  `coordinates` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `approved` tinyint(1) DEFAULT '0' COMMENT 'Whether the martyr has been approved by admin',
  PRIMARY KEY (`id`),
  KEY `idx_name` (`full_name`),
  KEY `idx_location` (`place_of_martyrdom`),
  KEY `idx_date` (`date_of_martyrdom`),
  KEY `idx_approved` (`approved`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `martyrs`
INSERT INTO `martyrs` (`id`, `full_name`, `photo_url`, `place_of_martyrdom`, `date_of_martyrdom`, `age`, `biography`, `education`, `occupation`, `role`, `personal_story`, `attachments`, `coordinates`, `created_at`, `updated_at`, `approved`) VALUES (1, 'Ahmad Al-Masri', NULL, 'Gaza City', '"2023-10-15T00:00:00.000Z"', 25, 'Ahmad was a dedicated teacher who believed in the power of education to change lives. He taught mathematics at a local school and was known for his patience and kindness towards his students.', 'Bachelor of Mathematics', 'Teacher', 'Educator', NULL, NULL, NULL, '"2025-08-31T19:17:50.000Z"', '"2025-08-31T19:17:50.000Z"', 0);
INSERT INTO `martyrs` (`id`, `full_name`, `photo_url`, `place_of_martyrdom`, `date_of_martyrdom`, `age`, `biography`, `education`, `occupation`, `role`, `personal_story`, `attachments`, `coordinates`, `created_at`, `updated_at`, `approved`) VALUES (2, 'Fatima Al-Zahra', NULL, 'Rafah', '"2023-11-20T00:00:00.000Z"', 32, 'Fatima was a nurse who dedicated her life to helping others. She worked at the local hospital and was known for her compassion and dedication to her patients.', 'Nursing Degree', 'Nurse', 'Healthcare Worker', NULL, NULL, NULL, '"2025-08-31T19:17:50.000Z"', '"2025-08-31T19:17:50.000Z"', 0);
INSERT INTO `martyrs` (`id`, `full_name`, `photo_url`, `place_of_martyrdom`, `date_of_martyrdom`, `age`, `biography`, `education`, `occupation`, `role`, `personal_story`, `attachments`, `coordinates`, `created_at`, `updated_at`, `approved`) VALUES (3, 'Omar Al-Hassan', NULL, 'Khan Yunis', '"2023-12-05T00:00:00.000Z"', 28, 'Omar was a civil engineer who worked on infrastructure projects to improve his community. He was passionate about building a better future for his people.', 'Civil Engineering Degree', 'Engineer', 'Infrastructure Developer', NULL, NULL, NULL, '"2025-08-31T19:17:50.000Z"', '"2025-08-31T19:17:50.000Z"', 0);
INSERT INTO `martyrs` (`id`, `full_name`, `photo_url`, `place_of_martyrdom`, `date_of_martyrdom`, `age`, `biography`, `education`, `occupation`, `role`, `personal_story`, `attachments`, `coordinates`, `created_at`, `updated_at`, `approved`) VALUES (4, 'Layla Al-Rashid', NULL, 'Beit Lahia', '"2024-01-10T00:00:00.000Z"', 19, 'Layla was a student studying medicine. She had dreams of becoming a doctor to help her community. She was known for her intelligence and determination.', 'Medical Student', 'Student', 'Future Doctor', NULL, NULL, NULL, '"2025-08-31T19:17:50.000Z"', '"2025-08-31T19:17:50.000Z"', 0);
INSERT INTO `martyrs` (`id`, `full_name`, `photo_url`, `place_of_martyrdom`, `date_of_martyrdom`, `age`, `biography`, `education`, `occupation`, `role`, `personal_story`, `attachments`, `coordinates`, `created_at`, `updated_at`, `approved`) VALUES (5, 'Yusuf Al-Nasser', NULL, 'Jabalia', '"2024-02-15T00:00:00.000Z"', 45, 'Yusuf was a farmer who provided food for his family and community. He was known for his hard work and generosity in sharing his harvest with those in need.', 'High School Education', 'Farmer', 'Food Provider', NULL, NULL, NULL, '"2025-08-31T19:17:50.000Z"', '"2025-08-31T19:17:50.000Z"', 0);
INSERT INTO `martyrs` (`id`, `full_name`, `photo_url`, `place_of_martyrdom`, `date_of_martyrdom`, `age`, `biography`, `education`, `occupation`, `role`, `personal_story`, `attachments`, `coordinates`, `created_at`, `updated_at`, `approved`) VALUES (6, 'Aisha Al-Mahmoud', NULL, 'Deir Al-Balah', '"2024-03-01T00:00:00.000Z"', 35, 'Aisha was a social worker who helped families in need. She was known for her empathy and dedication to improving the lives of others.', 'Social Work Degree', 'Social Worker', 'Community Helper', NULL, NULL, NULL, '"2025-08-31T19:17:50.000Z"', '"2025-08-31T19:17:50.000Z"', 0);
INSERT INTO `martyrs` (`id`, `full_name`, `photo_url`, `place_of_martyrdom`, `date_of_martyrdom`, `age`, `biography`, `education`, `occupation`, `role`, `personal_story`, `attachments`, `coordinates`, `created_at`, `updated_at`, `approved`) VALUES (7, 'Khalil Al-Omar', NULL, 'Beit Hanoun', '"2024-03-20T00:00:00.000Z"', 29, 'Khalil was a journalist who reported on the truth and documented the struggles of his people. He was committed to telling stories that needed to be heard.', 'Journalism Degree', 'Journalist', 'Truth Seeker', NULL, NULL, NULL, '"2025-08-31T19:17:50.000Z"', '"2025-08-31T19:17:50.000Z"', 0);
INSERT INTO `martyrs` (`id`, `full_name`, `photo_url`, `place_of_martyrdom`, `date_of_martyrdom`, `age`, `biography`, `education`, `occupation`, `role`, `personal_story`, `attachments`, `coordinates`, `created_at`, `updated_at`, `approved`) VALUES (8, 'Nour Al-Sabah', NULL, 'Al-Qarara', '"2024-04-05T00:00:00.000Z"', 22, 'Nour was an artist who used her creativity to express the beauty and pain of her homeland. Her paintings captured the spirit of resilience.', 'Fine Arts Degree', 'Artist', 'Cultural Expressionist', NULL, NULL, NULL, '"2025-08-31T19:17:50.000Z"', '"2025-08-31T19:17:50.000Z"', 0);
INSERT INTO `martyrs` (`id`, `full_name`, `photo_url`, `place_of_martyrdom`, `date_of_martyrdom`, `age`, `biography`, `education`, `occupation`, `role`, `personal_story`, `attachments`, `coordinates`, `created_at`, `updated_at`, `approved`) VALUES (9, 'Mahmoud Al-Rahman', NULL, 'Abu Salim', '"2024-04-25T00:00:00.000Z"', 38, 'Mahmoud was a carpenter who built furniture and homes for families. He was known for his craftsmanship and willingness to help others.', 'Vocational Training', 'Carpenter', 'Builder', NULL, NULL, NULL, '"2025-08-31T19:17:50.000Z"', '"2025-08-31T19:17:50.000Z"', 0);
INSERT INTO `martyrs` (`id`, `full_name`, `photo_url`, `place_of_martyrdom`, `date_of_martyrdom`, `age`, `biography`, `education`, `occupation`, `role`, `personal_story`, `attachments`, `coordinates`, `created_at`, `updated_at`, `approved`) VALUES (10, 'Samira Al-Hakim', NULL, 'Al-Maghazi', '"2024-05-10T00:00:00.000Z"', 27, 'Samira was a pharmacist who provided essential medicines to her community. She was known for her knowledge and dedication to public health.', 'Pharmacy Degree', 'Pharmacist', 'Healthcare Provider', NULL, NULL, NULL, '"2025-08-31T19:17:50.000Z"', '"2025-08-31T19:17:50.000Z"', 0);

-- Table structure for table `media_gallery`
DROP TABLE IF EXISTS `media_gallery`;
CREATE TABLE `media_gallery` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `file_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_type` enum('image','video','document') COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_category` (`category`),
  KEY `idx_public` (`is_public`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `media_gallery`
INSERT INTO `media_gallery` (`id`, `title`, `description`, `file_url`, `file_type`, `category`, `is_public`, `created_at`, `updated_at`) VALUES (1, 'Memorial Service', 'Community gathering to honor our martyrs', '/uploads/media/memorial-service.jpg', 'image', 'events', 1, '"2025-08-31T19:17:50.000Z"', '"2025-08-31T19:17:50.000Z"');
INSERT INTO `media_gallery` (`id`, `title`, `description`, `file_url`, `file_type`, `category`, `is_public`, `created_at`, `updated_at`) VALUES (2, 'Community Support', 'People coming together to support families', '/uploads/media/community-support.jpg', 'image', 'events', 1, '"2025-08-31T19:17:50.000Z"', '"2025-08-31T19:17:50.000Z"');
INSERT INTO `media_gallery` (`id`, `title`, `description`, `file_url`, `file_type`, `category`, `is_public`, `created_at`, `updated_at`) VALUES (3, 'Educational Program', 'Program to educate about our martyrs', '/uploads/media/education-program.jpg', 'image', 'education', 1, '"2025-08-31T19:17:50.000Z"', '"2025-08-31T19:17:50.000Z"');
INSERT INTO `media_gallery` (`id`, `title`, `description`, `file_url`, `file_type`, `category`, `is_public`, `created_at`, `updated_at`) VALUES (4, 'Historical Document', 'Important historical document about martyrs', '/uploads/documents/historical-doc.pdf', 'document', 'documents', 1, '"2025-08-31T19:17:50.000Z"', '"2025-08-31T19:17:50.000Z"');
INSERT INTO `media_gallery` (`id`, `title`, `description`, `file_url`, `file_type`, `category`, `is_public`, `created_at`, `updated_at`) VALUES (5, 'Memorial Video', 'Video tribute to our martyrs', '/uploads/media/memorial-video.mp4', 'video', 'tributes', 1, '"2025-08-31T19:17:50.000Z"', '"2025-08-31T19:17:50.000Z"');

-- Table structure for table `statistics`
DROP TABLE IF EXISTS `statistics`;
CREATE TABLE `statistics` (
  `id` int NOT NULL AUTO_INCREMENT,
  `stat_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stat_value` json NOT NULL,
  `last_updated` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stat_type` (`stat_type`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `statistics`
INSERT INTO `statistics` (`id`, `stat_type`, `stat_value`, `last_updated`) VALUES (1, 'total_martyrs', '{"count":10,"last_updated":"2024-01-01T00:00:00Z"}', '"2025-08-31T19:17:50.000Z"');
INSERT INTO `statistics` (`id`, `stat_type`, `stat_value`, `last_updated`) VALUES (2, 'martyrs_by_year', '{"2023":3,"2024":7,"last_updated":"2024-01-01T00:00:00Z"}', '"2025-08-31T19:17:50.000Z"');
INSERT INTO `statistics` (`id`, `stat_type`, `stat_value`, `last_updated`) VALUES (3, 'martyrs_by_location', '{"Rafah":1,"Jabalia":1,"Abu Salim":1,"Al-Qarara":1,"Gaza City":1,"Al-Maghazi":1,"Beit Lahia":1,"Khan Yunis":1,"Beit Hanoun":1,"last_updated":"2024-01-01T00:00:00Z","Deir Al-Balah":1}', '"2025-08-31T19:17:50.000Z"');
INSERT INTO `statistics` (`id`, `stat_type`, `stat_value`, `last_updated`) VALUES (4, 'age_distribution', '{"51+":1,"0-17":0,"18-30":4,"31-50":5,"last_updated":"2024-01-01T00:00:00Z"}', '"2025-08-31T19:17:50.000Z"');
INSERT INTO `statistics` (`id`, `stat_type`, `stat_value`, `last_updated`) VALUES (5, 'total_tributes', '{"count":11,"pending":0,"approved":11,"last_updated":"2024-01-01T00:00:00Z"}', '"2025-08-31T19:17:50.000Z"');

-- Table structure for table `tributes`
DROP TABLE IF EXISTS `tributes`;
CREATE TABLE `tributes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `martyr_id` int NOT NULL,
  `visitor_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_approved` tinyint(1) DEFAULT '0',
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_martyr_id` (`martyr_id`),
  KEY `idx_approved` (`is_approved`),
  CONSTRAINT `tributes_ibfk_1` FOREIGN KEY (`martyr_id`) REFERENCES `martyrs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `tributes`
INSERT INTO `tributes` (`id`, `martyr_id`, `visitor_name`, `message`, `is_approved`, `ip_address`, `created_at`) VALUES (1, 1, 'Ahmed', 'Ahmad was my teacher. He taught me not just mathematics, but also about life and perseverance. I will never forget his kindness.', 1, '192.168.1.1', '"2025-08-31T19:17:50.000Z"');
INSERT INTO `tributes` (`id`, `martyr_id`, `visitor_name`, `message`, `is_approved`, `ip_address`, `created_at`) VALUES (2, 1, 'Mariam', 'Thank you for being such an inspiring teacher. Your lessons will live on in the hearts of your students.', 1, '192.168.1.2', '"2025-08-31T19:17:50.000Z"');
INSERT INTO `tributes` (`id`, `martyr_id`, `visitor_name`, `message`, `is_approved`, `ip_address`, `created_at`) VALUES (3, 2, 'Dr. Hassan', 'Fatima was an exceptional nurse. Her dedication to her patients was unmatched. She will be deeply missed.', 1, '192.168.1.3', '"2025-08-31T19:17:50.000Z"');
INSERT INTO `tributes` (`id`, `martyr_id`, `visitor_name`, `message`, `is_approved`, `ip_address`, `created_at`) VALUES (4, 3, 'Community Member', 'Omar''s work on our infrastructure projects made a real difference in our lives. He was a true community leader.', 1, '192.168.1.4', '"2025-08-31T19:17:50.000Z"');
INSERT INTO `tributes` (`id`, `martyr_id`, `visitor_name`, `message`, `is_approved`, `ip_address`, `created_at`) VALUES (5, 4, 'Classmate', 'Layla was the brightest student in our class. She had so much potential and was always helping others with their studies.', 1, '192.168.1.5', '"2025-08-31T19:17:50.000Z"');
INSERT INTO `tributes` (`id`, `martyr_id`, `visitor_name`, `message`, `is_approved`, `ip_address`, `created_at`) VALUES (6, 5, 'Neighbor', 'Yusuf was a generous man who always shared his harvest with those in need. His kindness touched many lives.', 1, '192.168.1.6', '"2025-08-31T19:17:50.000Z"');
INSERT INTO `tributes` (`id`, `martyr_id`, `visitor_name`, `message`, `is_approved`, `ip_address`, `created_at`) VALUES (7, 6, 'Client', 'Aisha helped my family through difficult times. Her compassion and support meant everything to us.', 1, '192.168.1.7', '"2025-08-31T19:17:50.000Z"');
INSERT INTO `tributes` (`id`, `martyr_id`, `visitor_name`, `message`, `is_approved`, `ip_address`, `created_at`) VALUES (8, 7, 'Colleague', 'Khalil was a brave journalist who always told the truth, no matter the cost. His reporting made a difference.', 1, '192.168.1.8', '"2025-08-31T19:17:50.000Z"');
INSERT INTO `tributes` (`id`, `martyr_id`, `visitor_name`, `message`, `is_approved`, `ip_address`, `created_at`) VALUES (9, 8, 'Art Lover', 'Nour''s paintings captured the beauty and resilience of our people. Her art will continue to inspire future generations.', 1, '192.168.1.9', '"2025-08-31T19:17:50.000Z"');
INSERT INTO `tributes` (`id`, `martyr_id`, `visitor_name`, `message`, `is_approved`, `ip_address`, `created_at`) VALUES (10, 9, 'Customer', 'Mahmoud built beautiful furniture for my family. His craftsmanship and honesty were exceptional.', 1, '192.168.1.10', '"2025-08-31T19:17:50.000Z"');
INSERT INTO `tributes` (`id`, `martyr_id`, `visitor_name`, `message`, `is_approved`, `ip_address`, `created_at`) VALUES (11, 10, 'Patient', 'Samira always took the time to explain my medications and ensure I understood how to take them properly. She was truly caring.', 1, '192.168.1.11', '"2025-08-31T19:17:50.000Z"');

