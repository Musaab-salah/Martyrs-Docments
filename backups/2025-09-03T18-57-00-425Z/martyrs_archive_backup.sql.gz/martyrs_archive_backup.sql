-- Database Backup for martyrs_archive
-- Created: 2025-09-03T18:57:00.744Z
-- Server: localhost:3306

-- Table structure for table `admins`
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','super_admin') DEFAULT 'admin',
  `is_active` tinyint(1) DEFAULT 1,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_username` (`username`),
  KEY `idx_email` (`email`),
  KEY `idx_role` (`role`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `admins`
INSERT INTO `admins` (`id`, `username`, `email`, `password_hash`, `role`, `is_active`, `last_login`, `created_at`, `updated_at`) VALUES (1, 'sudansust', 'admin@martyrsarchive.com', '$2a$12$H.NvjNDmZCGq9N9AhxIE4OSkx5sp1VqeMYe.klM/TuAEAywK6eKe6', 'super_admin', 1, NULL, '"2025-09-03T17:53:45.000Z"', '"2025-09-03T17:53:45.000Z"');

-- Table structure for table `martyrs`
DROP TABLE IF EXISTS `martyrs`;
CREATE TABLE `martyrs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_ar` varchar(255) NOT NULL COMMENT 'Name in Arabic',
  `name_en` varchar(255) NOT NULL COMMENT 'Name in English',
  `date_of_martyrdom` date NOT NULL,
  `place_of_martyrdom` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT '{"state": "الخرطوم", "location": "الخرطوم بحري"}' CHECK (json_valid(`place_of_martyrdom`)),
  `education_level` enum('خريج','جامعي','مدرسة') NOT NULL,
  `university_name` varchar(255) DEFAULT NULL,
  `faculty` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `school_state` varchar(255) DEFAULT NULL,
  `school_locality` varchar(255) DEFAULT NULL,
  `spouse` varchar(255) DEFAULT NULL,
  `children` int(11) DEFAULT NULL,
  `occupation` varchar(255) NOT NULL,
  `bio` text DEFAULT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending' COMMENT 'Status of martyr record',
  `approved` tinyint(1) DEFAULT 0 COMMENT 'Whether the martyr has been approved by admin (for backward compatibility)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_name_ar` (`name_ar`),
  KEY `idx_name_en` (`name_en`),
  KEY `idx_date` (`date_of_martyrdom`),
  KEY `idx_status` (`status`),
  KEY `idx_approved` (`approved`),
  KEY `idx_education` (`education_level`),
  KEY `idx_occupation` (`occupation`),
  KEY `idx_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `martyrs`
INSERT INTO `martyrs` (`id`, `name_ar`, `name_en`, `date_of_martyrdom`, `place_of_martyrdom`, `education_level`, `university_name`, `faculty`, `department`, `school_state`, `school_locality`, `spouse`, `children`, `occupation`, `bio`, `image_url`, `status`, `approved`, `created_at`, `updated_at`) VALUES (1, 'محمد أحمد علي', 'Mohamed Ahmed Ali', '"2024-01-14T20:00:00.000Z"', '{"state": "الخرطوم", "location": "الخرطوم بحري"}', 'جامعي', 'جامعة الخرطوم', 'الهندسة', 'مدني', NULL, NULL, NULL, NULL, 'مهندس مدني', 'كان مثالاً للشجاعة والتفاني في خدمة الوطن. عمل على مشاريع البنية التحتية المهمة.', NULL, 'approved', 1, '"2025-09-03T17:53:45.000Z"', '"2025-09-03T17:53:45.000Z"');
INSERT INTO `martyrs` (`id`, `name_ar`, `name_en`, `date_of_martyrdom`, `place_of_martyrdom`, `education_level`, `university_name`, `faculty`, `department`, `school_state`, `school_locality`, `spouse`, `children`, `occupation`, `bio`, `image_url`, `status`, `approved`, `created_at`, `updated_at`) VALUES (2, 'فاطمة محمد حسن', 'Fatima Mohamed Hassan', '"2024-02-19T20:00:00.000Z"', '{"state": "الخرطوم", "location": "أم درمان"}', 'خريج', 'جامعة السودان', 'الطب', 'طب عام', NULL, NULL, NULL, NULL, 'طبيبة', 'كرست حياتها لعلاج المرضى ومساعدة المحتاجين. كانت مثالاً للرحمة والإنسانية.', NULL, 'approved', 1, '"2025-09-03T17:53:45.000Z"', '"2025-09-03T17:53:45.000Z"');
INSERT INTO `martyrs` (`id`, `name_ar`, `name_en`, `date_of_martyrdom`, `place_of_martyrdom`, `education_level`, `university_name`, `faculty`, `department`, `school_state`, `school_locality`, `spouse`, `children`, `occupation`, `bio`, `image_url`, `status`, `approved`, `created_at`, `updated_at`) VALUES (3, 'أحمد عمر محمد', 'Ahmed Omar Mohamed', '"2024-03-09T20:00:00.000Z"', '{"state": "الخرطوم", "location": "الخرطوم"}', 'مدرسة', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'طالب', 'كان طالباً مجتهداً يحلم بمستقبل أفضل لبلاده. كان مثالاً للشباب الواعي.', NULL, 'approved', 1, '"2025-09-03T17:53:45.000Z"', '"2025-09-03T17:53:45.000Z"');

-- Table structure for table `media_gallery`
DROP TABLE IF EXISTS `media_gallery`;
CREATE TABLE `media_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `file_url` varchar(500) NOT NULL,
  `file_type` enum('image','video','document') NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_category` (`category`),
  KEY `idx_public` (`is_public`),
  KEY `idx_file_type` (`file_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- No data for table `media_gallery`

-- Table structure for table `statistics`
DROP TABLE IF EXISTS `statistics`;
CREATE TABLE `statistics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stat_type` varchar(100) NOT NULL,
  `stat_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`stat_value`)),
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `stat_type` (`stat_type`),
  KEY `idx_stat_type` (`stat_type`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `statistics`
INSERT INTO `statistics` (`id`, `stat_type`, `stat_value`, `last_updated`) VALUES (1, 'total_martyrs', '{"count": 3, "last_updated": "2024-01-01T00:00:00Z"}', '"2025-09-03T17:53:45.000Z"');
INSERT INTO `statistics` (`id`, `stat_type`, `stat_value`, `last_updated`) VALUES (2, 'martyrs_by_education', '{"خريج": 1, "جامعي": 1, "مدرسة": 1, "last_updated": "2024-01-01T00:00:00Z"}', '"2025-09-03T17:53:45.000Z"');
INSERT INTO `statistics` (`id`, `stat_type`, `stat_value`, `last_updated`) VALUES (3, 'total_tributes', '{"count": 3, "approved": 3, "pending": 0, "last_updated": "2024-01-01T00:00:00Z"}', '"2025-09-03T17:53:45.000Z"');

-- Table structure for table `tributes`
DROP TABLE IF EXISTS `tributes`;
CREATE TABLE `tributes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `martyr_id` int(11) NOT NULL,
  `visitor_name` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `is_approved` tinyint(1) DEFAULT 0,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_martyr_id` (`martyr_id`),
  KEY `idx_approved` (`is_approved`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_ip_address` (`ip_address`),
  CONSTRAINT `tributes_ibfk_1` FOREIGN KEY (`martyr_id`) REFERENCES `martyrs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Data for table `tributes`
INSERT INTO `tributes` (`id`, `martyr_id`, `visitor_name`, `message`, `is_approved`, `ip_address`, `created_at`, `updated_at`) VALUES (1, 1, 'أحمد', 'كان أخاً عزيزاً وصديقاً وفياً. سنفتقده كثيراً.', 1, '192.168.1.1', '"2025-09-03T17:53:45.000Z"', '"2025-09-03T17:53:45.000Z"');
INSERT INTO `tributes` (`id`, `martyr_id`, `visitor_name`, `message`, `is_approved`, `ip_address`, `created_at`, `updated_at`) VALUES (2, 1, 'مريم', 'كان مثالاً للشجاعة والتفاني. رحمه الله.', 1, '192.168.1.2', '"2025-09-03T17:53:45.000Z"', '"2025-09-03T17:53:45.000Z"');
INSERT INTO `tributes` (`id`, `martyr_id`, `visitor_name`, `message`, `is_approved`, `ip_address`, `created_at`, `updated_at`) VALUES (3, 2, 'د. حسن', 'كانت طبيبة ممتازة وكرست حياتها لخدمة المرضى.', 1, '192.168.1.3', '"2025-09-03T17:53:45.000Z"', '"2025-09-03T17:53:45.000Z"');

